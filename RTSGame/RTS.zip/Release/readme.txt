==================|
Prototype Controls|
==================|

Mouse Edges     Pan the camera
Q + Mouse Edges Orbit the camera
Scroll wheel 	Zoom the camera in and out
1/2	 	Toggle the selected team
7/8/9 		Toggle the selected unit type for spawning
Q (held) 	Right-click to spawn toggled unit types at the cursor location
Click and drag  Select units (must be on team 1)
Right-click 	Command the selected units to move or target an enemy
~ 		Toggle the dev console, which can accept various commands for 				batch spawning or killing

====================|
Dev Console Commands|
====================|

Spawn Units	"spawn [{0},{1},{2},{3},{4}]" (spawn a squad of units)
		0 = Team Index (0/1)
		1 = Unit Type (0/1/2)
		2 = Spawn Count (Maximum Supported is 1000 of each unit type for 			each team else game will crash)
		3 = X Location (10-190)
		4 = Y Location (10 - 190)
Stop Motion	"stop motion" (this has a bug currently)
Killing Curse	"avada kedavra" (damages all units on the map by 9001)
